package com.iLaczen.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iLaczen.entities.MyOrder;

public interface MyOderRepository extends JpaRepository<MyOrder, Long>{

	
	public MyOrder findByOrderId(String orderId);
}
