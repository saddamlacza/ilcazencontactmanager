package com.iLaczen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class iLaczenPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(iLaczenPortalApplication.class, args);

		System.out.println("Server is Running Fine..");
	}

}
