package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class iLaczenPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
